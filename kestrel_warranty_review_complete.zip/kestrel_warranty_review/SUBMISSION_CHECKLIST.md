# Before you submit

- [x] `predictions.csv` exists at project root, has `claim_id,score`, 2,252 rows, follows test order, and has no missing scores.
- [x] API and UI run locally without paid keys.
- [x] Smoke tests pass.
- [x] Validation evidence and decision memo included.
- [ ] Record your own screen walkthrough under 3 minutes and paste the actual link in `submission-form-draft.md`.
- [ ] Enter your actual hours in the form.
- [ ] Paste approved Google Drive and GitHub URLs in the form.
- [ ] Confirm the evaluator's approved method for sharing restricted claim data before pushing any operational data, predictions, or a model trained on those data to a public repository. The policy in the pack prohibits public sharing of operational data; do not assume the public-repository request overrides that restriction.
