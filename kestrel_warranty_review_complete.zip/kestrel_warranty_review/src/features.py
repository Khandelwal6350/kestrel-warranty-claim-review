import re
import numpy as np
import pandas as pd

def build_features(claims, partners, products):
    """Deterministic, policy-aware features. No investigation outcome is used."""
    df = claims.copy()
    df["submitted_at"] = pd.to_datetime(df["submitted_at"], errors="coerce")
    df["partner_id"] = df["partner_id"].fillna("UNKNOWN").astype(str)
    df["sku"] = df["sku"].fillna("UNKNOWN").astype(str)
    df["source"] = df.get("source", pd.Series("unknown", index=df.index)).fillna("unknown").astype(str)
    for col in ["photo_attached", "partner_inspected"]:
        df[col] = df[col].fillna("N").astype(str).str.upper().str.strip()
    df["product_serial"] = df["product_serial"].fillna("").astype(str).str.upper().str.strip()
    serial = df["product_serial"].str.replace(r"[^A-Z0-9]", "", regex=True)
    df["serial_len"] = serial.str.len()
    df["serial_lowercase_or_spaces"] = df["product_serial"].ne(serial).astype(int)
    df["serial_missing"] = serial.eq("").astype(int)
    df["serial_has_letters"] = serial.str.contains(r"[A-Z]", regex=True).astype(int)
    df["serial_has_digits"] = serial.str.contains(r"\d", regex=True).astype(int)
    df["serial_digit_fraction"] = serial.apply(lambda s: sum(c.isdigit() for c in s) / max(len(s), 1))
    df["days_since_purchase"] = pd.to_numeric(df["days_since_purchase"], errors="coerce")
    df["claim_amount_inr"] = pd.to_numeric(df["claim_amount_inr"], errors="coerce")
    df["customer_prior_claims"] = pd.to_numeric(df["customer_prior_claims"], errors="coerce")
    df["claim_description"] = df.get("claim_description", pd.Series("", index=df.index)).fillna("").astype(str)
    df["inspector_note"] = df.get("inspector_note", pd.Series("", index=df.index)).fillna("").astype(str)
    desc = df["claim_description"].str.lower()
    note = df["inspector_note"].str.lower()
    df["description_length"] = desc.str.len()
    df["description_word_count"] = desc.str.split().str.len()
    df["note_length"] = note.str.len()
    df["note_present"] = note.str.strip().ne("").astype(int)
    df["description_generic"] = desc.str.contains(r"\b(?:not working|issue|problem|fault|damaged|broken)\b", regex=True).astype(int)
    df["note_verification"] = note.str.contains(r"\b(?:verified|bill|serial|confirmed|genuine)\b", regex=True).astype(int)
    df["note_suspicious"] = note.str.contains(r"\b(?:duplicate|mismatch|tamper|fake|no fault|not found|altered)\b", regex=True).astype(int)
    dt = df["submitted_at"]
    df["submit_month"] = dt.dt.month.fillna(0).astype(int).astype(str)
    df["submit_dayofweek"] = dt.dt.dayofweek.fillna(-1).astype(int).astype(str)
    df["submit_hour"] = dt.dt.hour.fillna(-1).astype(int)
    df["submit_days_from_start"] = (dt - pd.Timestamp("2025-04-01")).dt.total_seconds().div(86400).fillna(0)
    # Policy changed on 1 May 2026: claims under Rs 2,000 may be auto-approved without inspection.
    df["post_policy_change"] = (dt >= pd.Timestamp("2026-05-01")).fillna(False).astype(int)
    df["low_value_post_change_uninspected"] = ((df["post_policy_change"] == 1) & (df["claim_amount_inr"] < 2000) & (df["partner_inspected"] != "Y")).astype(int)
    df["amount_to_product_list_price"] = np.nan
    p = products.copy()
    p["sku"] = p["sku"].astype(str)
    df = df.merge(p[["sku","family","list_price_inr","warranty_months"]], on="sku", how="left", validate="many_to_one")
    df["amount_to_product_list_price"] = df["claim_amount_inr"] / pd.to_numeric(df["list_price_inr"], errors="coerce").replace(0, np.nan)
    df["outside_warranty_days"] = (df["days_since_purchase"] > pd.to_numeric(df["warranty_months"], errors="coerce") * 30.4375).astype(int)
    pr = partners.copy()
    pr["partner_id"] = pr["partner_id"].astype(str)
    pr["onboarded_date"] = pd.to_datetime(pr["onboarded_date"], errors="coerce")
    df = df.merge(pr[["partner_id","city","partner_type","onboarded_date"]], on="partner_id", how="left", validate="many_to_one")
    df["partner_tenure_days"] = (df["submitted_at"] - df["onboarded_date"]).dt.total_seconds().div(86400)
    df["partner_new_90d"] = ((df["partner_tenure_days"] >= 0) & (df["partner_tenure_days"] <= 90)).astype(int)
    df["partner_new_180d"] = ((df["partner_tenure_days"] >= 0) & (df["partner_tenure_days"] <= 180)).astype(int)
    df["partner_tenure_days"] = df["partner_tenure_days"].fillna(-1)
    # Categorical features and structured numeric features.
    categorical = ["partner_id","sku","source","photo_attached","partner_inspected","family","city","partner_type","submit_month","submit_dayofweek"]
    numeric = ["days_since_purchase","claim_amount_inr","customer_prior_claims","serial_len","serial_lowercase_or_spaces","serial_missing","serial_has_letters","serial_has_digits","serial_digit_fraction","description_length","description_word_count","note_length","note_present","description_generic","note_verification","note_suspicious","submit_hour","submit_days_from_start","post_policy_change","low_value_post_change_uninspected","amount_to_product_list_price","outside_warranty_days","partner_tenure_days","partner_new_90d","partner_new_180d"]
    for c in categorical:
        df[c] = df[c].fillna("UNKNOWN").astype(str)
    for c in numeric:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    # Return plain columns; free text retained for TF-IDF in pipeline.
    keep = categorical + numeric + ["claim_description","inspector_note"]
    return df[keep].replace([np.inf,-np.inf], np.nan)


def select_text(x):
    return pd.Series(np.asarray(x).reshape(-1)).fillna("").astype(str).to_numpy()
