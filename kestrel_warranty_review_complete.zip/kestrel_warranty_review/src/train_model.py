import os, json, warnings
import numpy as np
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (average_precision_score, roc_auc_score, accuracy_score,
                             precision_score, recall_score, confusion_matrix, brier_score_loss)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import OneHotEncoder, StandardScaler, FunctionTransformer
from sklearn.linear_model import LogisticRegression
from features import build_features, select_text

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
ART = os.path.join(ROOT, "artifacts")
os.makedirs(ART, exist_ok=True)

train = pd.read_csv(os.path.join(DATA, "train.csv"))
test = pd.read_csv(os.path.join(DATA, "test_unlabelled.csv"))
partners = pd.read_csv(os.path.join(DATA, "partners.csv"))
products = pd.read_csv(os.path.join(DATA, "products.csv"))
# Explicitly exclude undecided outcomes; email thread says legacy blanks were exported as 0.
train["is_fraud"] = pd.to_numeric(train["is_fraud"], errors="coerce")
labelled = train[train["is_fraud"].isin([0,1])].copy()
labelled["is_fraud"] = labelled["is_fraud"].astype(int)
# Duplicate claim IDs are re-submissions. Keep the latest row per claim ID to avoid weighting
# resubmitted cases repeatedly and to reduce leakage across validation partitions.
labelled["submitted_at"] = pd.to_datetime(labelled["submitted_at"], errors="coerce")
labelled = labelled.sort_values("submitted_at").drop_duplicates("claim_id", keep="last")
Xall = build_features(labelled, partners, products)
yall = labelled["is_fraud"].to_numpy()
dates = labelled["submitted_at"]
# Temporal holdout: latest 20% of unique labelled claims; drop train rows with same IDs as holdout.
cutoff = dates.quantile(0.80)
valid_mask = dates >= cutoff
valid_ids = set(labelled.loc[valid_mask, "claim_id"])
train_mask = (~valid_mask) & (~labelled["claim_id"].isin(valid_ids))
if valid_mask.sum() < 100 or len(set(yall[valid_mask])) < 2:
    # fallback stratified split with claim IDs already deduplicated
    tr_idx, va_idx = train_test_split(np.arange(len(labelled)), test_size=0.2, random_state=42, stratify=yall)
else:
    tr_idx, va_idx = np.where(train_mask)[0], np.where(valid_mask)[0]
Xtr, Xva = Xall.iloc[tr_idx], Xall.iloc[va_idx]
ytr, yva = yall[tr_idx], yall[va_idx]
cat = ["partner_id","sku","source","photo_attached","partner_inspected","family","city","partner_type","submit_month","submit_dayofweek"]
num = [c for c in Xall.columns if c not in cat + ["claim_description","inspector_note"]]
def text_column(name):
    return FunctionTransformer(select_text, validate=False)
# Separate text vectorizers are combined with structured columns; all preprocessing is fit only on train split.
pre = ColumnTransformer([
    ("cat", OneHotEncoder(handle_unknown="ignore", min_frequency=2), cat),
    ("num", Pipeline([("impute", SimpleImputer(strategy="median", add_indicator=True)), ("scale", StandardScaler(with_mean=False))]), num),
    ("description", Pipeline([("select", text_column("claim_description")), ("tfidf", TfidfVectorizer(ngram_range=(1,2), min_df=3, max_features=12000, sublinear_tf=True))]), ["claim_description"]),
    ("inspector_note", Pipeline([("select", text_column("inspector_note")), ("tfidf", TfidfVectorizer(ngram_range=(1,2), min_df=2, max_features=8000, sublinear_tf=True))]), ["inspector_note"]),
], remainder="drop", sparse_threshold=0.3)
model = Pipeline([("preprocess", pre), ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced", C=0.35, solver="liblinear", random_state=42))])
model.fit(Xtr, ytr)
pva = model.predict_proba(Xva)[:,1]
# Metrics at 0.5 are diagnostic only; operating threshold should be chosen on a cost/capacity curve.
pred05 = (pva >= 0.5).astype(int)
cm = confusion_matrix(yva, pred05, labels=[0,1])
topn = min(40, len(pva))
top_idx = np.argsort(-pva)[:topn]
metrics = {
 "validation_method": "latest 20% by submitted_at after deduplicating claim_id; train/validation claim IDs disjoint",
 "validation_cutoff": str(cutoff),
 "train_rows": int(len(tr_idx)), "validation_rows": int(len(va_idx)),
 "train_fraud_count": int(ytr.sum()), "validation_fraud_count": int(yva.sum()),
 "validation_fraud_prevalence": float(np.mean(yva)),
 "average_precision_pr_auc": float(average_precision_score(yva,pva)),
 "roc_auc": float(roc_auc_score(yva,pva)) if len(set(yva))==2 else None,
 "brier_score": float(brier_score_loss(yva,pva)),
 "accuracy_at_0_5": float(accuracy_score(yva,pred05)),
 "precision_at_0_5": float(precision_score(yva,pred05,zero_division=0)),
 "recall_at_0_5": float(recall_score(yva,pred05,zero_division=0)),
 "confusion_matrix_labels_0_1": cm.tolist(),
 "precision_in_top_40_validation": float(np.mean(yva[top_idx])),
 "fraud_caught_in_top_40_validation": int(yva[top_idx].sum()),
 "note": "Top-40 is a simple capacity illustration only; validation spans more than one month and is not a calibrated monthly policy."
}
val_export = labelled.iloc[va_idx][["claim_id","submitted_at","claim_amount_inr","is_fraud"]].copy()
val_export["score"] = pva
val_export.sort_values("score", ascending=False).to_csv(os.path.join(ART,"validation_predictions.csv"), index=False)
with open(os.path.join(ART,"validation_metrics.json"),"w") as f: json.dump(metrics,f,indent=2)
# Refit on all adjudicated outcomes (deduplicated claim IDs) for final predictions.
final_model = Pipeline([("preprocess", pre), ("classifier", LogisticRegression(max_iter=2000, class_weight="balanced", C=0.35, solver="liblinear", random_state=42))])
final_model.fit(Xall, yall)
joblib.dump(final_model, os.path.join(ART,"fraud_model.joblib"))
Xt = build_features(test, partners, products)
scores = final_model.predict_proba(Xt)[:,1]
submission = pd.DataFrame({"claim_id":test["claim_id"].astype(str), "score":scores})
submission.to_csv(os.path.join(ROOT,"predictions.csv"),index=False)
# Keep model manifest and data integrity notes.
manifest = {"model":"TF-IDF + one-hot structured features + class-weighted logistic regression",
 "labelled_rows_used":int(len(labelled)), "fraud_rows_used":int(yall.sum()),
 "undecided_rows_excluded":int(train["is_fraud"].isna().sum()),
 "duplicate_claim_ids_collapsed":int(train[train["is_fraud"].isin([0,1])].shape[0]-len(labelled)),
 "test_rows_scored":int(len(test)), "score_semantics":"ranking score in [0,1], higher means more likely fraud; not a calibrated probability",
 "prediction_file":"predictions.csv"}
with open(os.path.join(ART,"model_manifest.json"),"w") as f: json.dump(manifest,f,indent=2)
print(json.dumps(metrics,indent=2))
print("manifest",json.dumps(manifest,indent=2))
