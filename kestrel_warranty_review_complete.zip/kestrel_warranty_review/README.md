# Kestrel Home — Warranty Claim Review (Variant C)

A local, no-paid-API prototype for ranking warranty claims for human review. Includes `predictions.csv`, a FastAPI scoring endpoint, a browser UI, temporal holdout evidence, a one-page operations memo, and draft submission-form answers.

## Important decision

**Do not deploy this model to make payment or rejection decisions.** The validation results are weak: ROC-AUC 0.560, PR-AUC 0.086, and the model's 0.5-threshold accuracy is 91.1%, below the 97.9% majority-class baseline on the temporal holdout. It does not meet the board's requested >97% accuracy, and a high accuracy number would be misleading because fraud is rare. The current version is a runnable prototype and evidence package, not a production-ready fraud detector.

## What is included

- `predictions.csv` — one row per test claim, with `claim_id,score`; higher score means more likely fraud.
- `app.py` and `web/index.html` — single-record JSON API and browser screen.
- `src/features.py` — policy-aware structured feature engineering.
- `src/train_model.py` — deterministic model training, temporal holdout evaluation and test scoring.
- `artifacts/fraud_model.joblib` — trained local model.
- `artifacts/validation_metrics.json` — held-out metrics.
- `artifacts/validation_predictions.csv` — held-out scores and labels for audit.
- `artifacts/model_manifest.json` — row counts and score semantics.
- `memo-to-ritu.md` — nontechnical one-page decision memo.
- `submission-form-draft.md` — draft answers for the submission form.
- `recording-script.md` — concise guide for making the required screen recording.
- `data/` — supplied files needed to reproduce the project locally.

## Run locally (Python 3.10–3.12 recommended)

From this directory:

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python src/train_model.py
uvicorn app:app --host 127.0.0.1 --port 8000
```

Open <http://127.0.0.1:8000>. API docs: <http://127.0.0.1:8000/docs>. Health check: <http://127.0.0.1:8000/health>.

No paid API key or external service is needed. The model runs locally. Re-training overwrites the model artifact, metrics, and `predictions.csv`.

## API example

```bash
curl -X POST http://127.0.0.1:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "claim_id":"DEMO-001",
    "submitted_at":"2026-07-10 10:30",
    "partner_id":"SP3219",
    "sku":"KH-MG-03",
    "product_serial":"kh123456789",
    "days_since_purchase":180,
    "claim_amount_inr":1800,
    "photo_attached":"N",
    "partner_inspected":"N",
    "claim_description":"motor not working",
    "inspector_note":"",
    "customer_prior_claims":1,
    "source":"crm"
  }'
```

The response includes `fraud_risk_score`, a short interpretation, review cues and limitations. Review cues are deterministic rule-based signals; they are **not** exact feature attributions from the statistical model.

## Method and data decisions

1. 12,029 training rows include 215 undecided labels. These are excluded rather than treating missing CRM outcomes as non-fraud.
2. The email thread says re-submissions can repeat claim numbers. For model development, adjudicated rows are sorted by timestamp and the latest row per `claim_id` is retained, preventing repeated IDs from overweighting training.
3. Holdout is the latest 20% by timestamp after deduplication, with claim IDs kept disjoint. This is a time-oriented check, not cross-validation and not a guarantee of future performance.
4. The model combines TF-IDF on claim descriptions and inspector notes, one-hot categorical features, engineered serial/date/policy features, and class-weighted logistic regression.
5. The policy change from 1 May 2026 is encoded explicitly: claims under ₹2,000 may be auto-approved without inspection after that date. This pattern is not itself proof of fraud.
6. The output score is a **ranking score, not a calibrated fraud probability**. No production threshold has been approved.

## Validation snapshot

See `artifacts/validation_metrics.json` for the full result. On 2,230 temporal holdout rows (47 fraud; 2.11% prevalence):

- PR-AUC / average precision: **0.086**
- ROC-AUC: **0.560**
- Accuracy at arbitrary threshold 0.5: **91.1%**
- Always-predict-not-fraud baseline accuracy: **97.9%**
- Top 40 scored rows: **4 fraud of 40 (10% precision)**

The top-40 result is a capacity illustration over the full holdout, not a monthly forecast. It is not strong enough to justify rollout. The model appears to have limited ranking signal and should be improved before an operational pilot.

## Known limitations / next work

- Only 141 fraud outcomes remain after deduplicating adjudicated claim IDs; estimates are noisy.
- The validation sample contains only 47 fraud cases and does not establish stable performance by product, partner, city, or time period.
- Partner IDs and free-text fields can encode historical investigation practices and could drift.
- Class weighting makes raw scores unsuitable as calibrated probabilities.
- Review reasons are rule-based cues and can differ from what most influenced the model.
- Current feature set does not resolve duplicate serials across claims or graph-like partner/customer/serial relationships.
- No automated decision threshold, monitoring, access control, authentication, audit retention, or production deployment has been implemented.
- A valid policy/warranty interpretation may require Kestrel Shield coverage and corrected legacy timestamps; this prototype does not resolve all such cases.
- The input pack's policy prohibits public sharing of operational data. **Do not push the supplied `data/` files or trained artifacts to a public repository.** If the evaluator requires a public GitHub URL, publish code/docs only after removing supplied claim/partner/product data and any model artifact trained on restricted data, or get written authorization. Keep `predictions.csv` only in the approved submission channel if required by the engagement.

## Reproducibility

```bash
python src/train_model.py
python -m unittest discover -s tests -v
```

The project intentionally records poor validation results rather than claiming >97% model accuracy.
