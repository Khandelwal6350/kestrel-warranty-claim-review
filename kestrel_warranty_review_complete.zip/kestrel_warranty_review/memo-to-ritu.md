# Decision memo — Kestrel warranty claim review
**To:** Ritu Deshpande, Head of D2C Operations  
**Subject:** Warranty fraud ranking prototype — do not deploy yet

## Decision

Do not use this model to block payments or automatically reject claims. The temporal holdout did not support the board's >97% accuracy target as a useful fraud detector. On 2,230 later claims, only 47 were fraud (2.1%). The model reached 91.1% accuracy at a generic 0.5 threshold, while simply calling every claim genuine would reach 97.9%. The more relevant ranking metrics were also weak: ROC-AUC 0.56 and PR-AUC 0.086.

## What the test says about money

Kestrel's policy says a fraudulent claim paid out costs the full claim amount; holding a genuine claim for review creates average goodwill cost of ₹380, plus ₹260 per service contact. The investigation desk can review at most 40 claims per month.

In the 2,230-claim holdout, the 40 highest-scored claims included 4 fraud cases (10% precision). This is only a pooled holdout illustration, not a monthly forecast. At that observed hit rate, 36 of 40 reviews would be genuine claims held. Their average goodwill exposure alone would be up to ₹13,680 (36 × ₹380), before service-contact costs (up to ₹10,400 if each caused one additional contact). The four fraudulent claims' amounts are ₹42,574 in total in this holdout sample, but this is not a reliable estimate of monthly avoided payouts. The present evidence does **not** establish positive net savings or justify using the full review capacity.

## What to do next week

1. Keep the model in shadow mode; do not alter approvals, payout timing or customer communications.
2. Audit the 40 highest-scored historical cases with investigators, and compare against the original case file, serial, product coverage, resubmissions and investigation rationale.
3. Fix label quality and capture missing investigation outcomes. Confirm whether repeat claim IDs represent the same case or a new claim, and normalize legacy Zoho timestamps.
4. Compare a transparent rules baseline and a partner/serial/claim-linkage approach using a time-based holdout. Report precision and rupees recovered per review, false holds and subgroup performance—not accuracy alone.
5. Only consider a small, human-reviewed pilot after the ranking signal improves and finance agrees on a threshold based on expected avoided payouts versus ₹380 goodwill and ₹260 contact costs.

## What we changed from the request

We did not claim >97% fraud-model accuracy: the rare fraud rate makes majority-class accuracy misleading. We also did not treat missing investigation outcomes as genuine claims, and we did not blame new partners as a group. The output is a ranking signal only. Partner tenure is a contextual cue, not evidence of fraud.

**Bottom line:** the service runs and the submission predictions are generated, but the model is not ready to influence customer or payout decisions.
