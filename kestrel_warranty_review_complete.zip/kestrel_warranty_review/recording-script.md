# Three-minute screen-recording guide (record your own screen; no slides)

**0:00–0:25 — The brief and the decision**  
Show the project folder and say: “I built a local claim-ranking service and predictions file. I pushed back on accuracy because fraud is rare; the all-genuine baseline is already 97.9%.”

**0:25–0:55 — Data decisions**  
Show `artifacts/model_manifest.json` and `artifacts/validation_metrics.json`. Explain that 215 undecided outcomes were excluded, repeat claim IDs were deduplicated, and validation used a later time window.

**0:55–1:35 — Run the product**  
Show terminal commands from README, open localhost:8000, fill the claim form, click Score claim. Point out the score is a ranking score and the reasons are rule-based review cues.

**1:35–2:15 — Evidence**  
Show PR-AUC 0.086, ROC-AUC 0.560, 91.1% accuracy at threshold 0.5 versus the 97.9% all-genuine baseline, and 4/40 precision in the top 40. State that this is not good enough to deploy.

**2:15–2:45 — What changed / what was discarded**  
Show `memo-to-ritu.md`. Explain why you rejected auto-rejection and did not blame new partners as a group.

**2:45–3:00 — Next step**  
Show `predictions.csv` row count and close with: “Next I would audit the highest-scored cases, improve labels and linkage features, then measure rupees saved per investigation.”

Keep the recording under three minutes, no slides, and paste the link into `submission-form-draft.md`.
