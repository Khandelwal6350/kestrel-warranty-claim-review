import unittest
from fastapi.testclient import TestClient
import app

class ServiceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app.app)

    def test_health(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["model_loaded"])

    def test_predict_returns_score_and_reasons(self):
        payload = {
            "claim_id":"TEST-1", "submitted_at":"2026-07-10 10:30",
            "partner_id":"SP3219", "sku":"KH-MG-03", "product_serial":"kh123456789",
            "days_since_purchase":180, "claim_amount_inr":1800,
            "photo_attached":"N", "partner_inspected":"N",
            "claim_description":"motor not working", "inspector_note":"",
            "customer_prior_claims":1, "source":"crm"
        }
        response = self.client.post("/predict", json=payload)
        self.assertEqual(response.status_code, 200, response.text)
        body = response.json()
        self.assertGreaterEqual(body["fraud_risk_score"], 0)
        self.assertLessEqual(body["fraud_risk_score"], 1)
        self.assertTrue(body["review_reasons"])
        self.assertIn("recommended_action", body)

if __name__ == "__main__":
    unittest.main()
