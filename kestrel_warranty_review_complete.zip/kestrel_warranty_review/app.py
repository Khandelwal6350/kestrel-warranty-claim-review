from pathlib import Path
import sys
import re
from datetime import datetime
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from typing import Optional
from src.features import build_features

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "artifacts" / "fraud_model.joblib"
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))
# features is importable as src.features when launched from the project root.
MODEL = joblib.load(MODEL_PATH)
PARTNERS = pd.read_csv(ROOT / "data" / "partners.csv")
PRODUCTS = pd.read_csv(ROOT / "data" / "products.csv")

app = FastAPI(title="Kestrel Warranty Claim Review", version="1.0.0",
              description="Decision-support ranking prototype; never auto-rejects claims.")

class Claim(BaseModel):
    claim_id: str = "DEMO-001"
    submitted_at: str
    partner_id: str
    sku: str
    product_serial: str = ""
    days_since_purchase: float = 0
    claim_amount_inr: float = 0
    photo_attached: str = "N"
    partner_inspected: str = "N"
    claim_description: str = ""
    inspector_note: Optional[str] = ""
    customer_prior_claims: float = 0
    source: str = "crm"

def make_reasons(c: dict, partner_row, product_row):
    reasons = []
    try:
        dt = pd.to_datetime(c.get("submitted_at"), errors="coerce")
    except Exception:
        dt = pd.NaT
    onboarded = pd.to_datetime(partner_row.get("onboarded_date"), errors="coerce") if partner_row is not None else pd.NaT
    tenure = (dt - onboarded).days if pd.notna(dt) and pd.notna(onboarded) else None
    amount = float(c.get("claim_amount_inr") or 0)
    days = float(c.get("days_since_purchase") or 0)
    prior = float(c.get("customer_prior_claims") or 0)
    serial = str(c.get("product_serial") or "")
    if tenure is not None and 0 <= tenure <= 180:
        reasons.append(f"Partner onboarded {tenure} days before this claim; use as context, not proof of fraud.")
    if pd.notna(dt) and dt >= pd.Timestamp("2026-05-01") and amount < 2000 and str(c.get("partner_inspected","N")).upper() != "Y":
        reasons.append("Under-Rs 2,000 post-policy claim without inspection matches the new auto-approval pathway; verify eligibility rather than treating this alone as suspicious.")
    if prior >= 2:
        reasons.append(f"Customer has {int(prior)} prior claim(s); check for linked cases and repeat-repair context.")
    if str(c.get("photo_attached","N")).upper() != "Y":
        reasons.append("No photo attached; evidence is limited.")
    if serial.strip() and (serial != serial.upper() or re_has_format_issue(serial)):
        reasons.append("Serial formatting is inconsistent; compare with the product label and purchase record.")
    if product_row is not None and pd.notna(product_row.get("warranty_months")) and days > float(product_row["warranty_months"]) * 30.4375:
        reasons.append("Reported purchase age exceeds the listed warranty duration; verify dates, coverage and any Kestrel Shield plan.")
    note = str(c.get("inspector_note") or "").lower()
    if any(k in note for k in ["duplicate","mismatch","tamper","fake","not found","altered"]):
        reasons.append("Inspector note contains a verification concern; read the original note before deciding.")
    if not reasons:
        reasons.append("No rule-based review cue fired. The model score is only a prioritisation signal.")
    return reasons[:5]

def re_has_format_issue(value):
    import re
    clean = re.sub(r"[^A-Z0-9]", "", value.upper())
    return len(clean) < 8 or len(clean) > 24

@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "web" / "index.html").read_text(encoding="utf-8")

@app.get("/health")
def health():
    return {"status":"ok","model_loaded":True,"mode":"decision_support_only"}

@app.post("/predict")
def predict(claim: Claim):
    row = claim.model_dump()
    partner = PARTNERS[PARTNERS.partner_id.astype(str) == str(row["partner_id"])]
    product = PRODUCTS[PRODUCTS.sku.astype(str) == str(row["sku"])]
    partner_row = partner.iloc[0].to_dict() if len(partner) else None
    product_row = product.iloc[0].to_dict() if len(product) else None
    try:
        X = build_features(pd.DataFrame([row]), PARTNERS, PRODUCTS)
        score = float(MODEL.predict_proba(X)[:,1][0])
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Could not score this claim: {exc}")
    reasons = make_reasons(row, partner_row, product_row)
    return {
        "claim_id": row["claim_id"],
        "fraud_risk_score": round(score, 6),
        "score_interpretation": "Higher means the model ranks this claim as more similar to historical fraud cases; this is not a calibrated probability.",
        "recommended_action": "Manual review candidate only; do not auto-reject or delay solely on this score.",
        "review_reasons": reasons,
        "limitations": ["Validation performance is weak (ROC-AUC about 0.56 and PR-AUC about 0.086).",
                        "Human-readable reasons are rule-based cues, not exact model explanations.",
                        "No score threshold has been approved for production."]
    }
