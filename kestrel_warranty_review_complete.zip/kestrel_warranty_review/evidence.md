# Evidence report

## Dataset accounting

| Item | Count |
|---|---:|
| Raw labelled export rows | 12,029 |
| Undecided outcome rows excluded | 215 |
| Adjudicated rows before claim-ID deduplication | 11,814 |
| Repeated rows removed by latest-per-claim-ID rule | 668 |
| Unique adjudicated claim IDs used for modelling | 11,146 |
| Fraud labels after deduplication | 141 |
| Test claims scored | 2,252 |

These counts are recorded in `artifacts/model_manifest.json`. Undecided labels were not silently changed to genuine claims.

## Validation method

The latest 20% of deduplicated claims by timestamp was held out, with claim IDs disjoint between train and validation. Cutoff: 2026-03-28 10:29. Training: 8,916 claims, 94 fraud. Validation: 2,230 claims, 47 fraud (2.11%).

## Results

| Metric | Result |
|---|---:|
| PR-AUC / average precision | 0.0862 |
| ROC-AUC | 0.5602 |
| Brier score | 0.0672 |
| Accuracy at generic 0.5 threshold | 91.08% |
| Majority-class baseline accuracy | 97.89% |
| Precision at 0.5 | 3.66% |
| Recall at 0.5 | 12.77% |
| Top-40 precision in full holdout | 10.0% (4 of 40) |

Confusion matrix at 0.5, rows actual `[genuine, fraud]`, columns predicted `[genuine, fraud]`:

```text
[[2025, 158],
 [  41,   6]]
```

This threshold is diagnostic, not a recommended operating threshold. The model's accuracy is worse than the trivial baseline; it must not be described as meeting the client's accuracy KPI.

## Error profile

At threshold 0.5, the model flags 164 claims, of which 158 are genuine (false positives), and misses 41 of 47 fraud claims (false negatives). The false-positive pattern creates customer delay costs, while false negatives still allow fraud payouts. The top-40 view is better aligned to capacity, but 10% precision is not strong enough to establish positive net value without more evidence.

## Rupee context

Policy inputs: fraudulent payout costs the full claim amount; a genuine claim held for review averages ₹380 goodwill; service contact cost is ₹260; investigation capacity is 40/month. For a 40-case review batch, 36 genuine holds would mean ₹13,680 goodwill and as many as ₹10,400 for 40 service contacts if every reviewed case generated one additional contact. The top 40 in this validation contained four fraud cases whose claim amounts totalled ₹42,574. These are observed values from one pooled holdout, not an estimate of monthly savings or a recommendation to review these cases in production.

## Interpretation

The model's PR-AUC is about four times the holdout fraud prevalence, but the absolute precision is still low and ROC-AUC is only slightly above random ranking. Small fraud sample size, possible label noise, legacy timestamp issues and changes in policy limit confidence. Next iteration should focus on label adjudication, repeat serial/claim linkage, partner-normalized rates with shrinkage, and investigator feedback. Re-evaluate on a future period and report net rupees per investigation before any live use.
