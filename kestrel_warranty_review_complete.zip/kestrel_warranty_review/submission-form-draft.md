# Submission form — draft answers (review before sending)

**What did you build, and what business outcome does it move? State the number and the money.**  
Built a local warranty-claim risk-ranking API and screen, plus `predictions.csv` for all 2,252 unlabelled claims. The intended outcome is to prioritize the 40 monthly investigation slots toward fraud with high claim values while limiting genuine-customer delay costs. Current evidence does not show reliable savings: in a 2,230-row temporal holdout, the top 40 contained 4 fraud cases (10% precision), and the fraud claim amounts among those four totalled ₹42,574. This is a pooled historical illustration, not a monthly savings forecast. At 36 genuine holds, policy goodwill exposure is ₹13,680 (36 × ₹380), plus up to ₹10,400 for 40 additional service contacts (40 × ₹260). Do not deploy until precision and expected net value improve.

**What does one run cost, and what would a month cost at Vireo's volume (roughly 650 tickets a week)? Show the arithmetic. If you used no paid calls, say so.**  
No paid API calls. One batch prediction run and one single-claim prediction use local CPU only; marginal paid-call cost is ₹0. At 650 tickets/week, estimated monthly volume = 650 × 52 ÷ 12 ≈ 2,817 tickets. Paid inference cost = 2,817 × ₹0 = ₹0/month, excluding hosting, electricity, and maintenance. (The brief's later Kestrel-specific volume question is answered separately below.)

**How do you know it works? Sample size, how you checked, error rate, and the kind of case it gets wrong.**  
A time-oriented holdout of 2,230 deduplicated, adjudicated claims (47 fraud; 2.11% prevalence) was used. PR-AUC 0.086, ROC-AUC 0.560, accuracy 91.1% at a generic 0.5 threshold, versus 97.9% for an all-genuine baseline. At that threshold, confusion matrix is TN 2,025, FP 158, FN 41, TP 6. Top 40 scores caught 4 fraud cases (10% precision). These results are weak; likely failure modes include subtle fraud with ordinary descriptions/serials and legitimate claims with unusual text or missing evidence. The holdout is small for fraud and does not prove future performance.

**Did you change, narrow, or push back on the client's ask? What, when, and why?**  
Yes. I pushed back on the >97% accuracy target after inspecting the 2.1% fraud prevalence: an all-genuine baseline already reaches 97.9%, so accuracy alone rewards a useless model. I excluded 215 undecided labels (including old-system ambiguity described in the email), deduplicated repeated claim IDs, used a time-oriented holdout, and made the output human-review-only. I did not infer that newer partners are fraudulent.

**What is wrong with what you are handing us? Be specific.**  
Ranking signal is weak (ROC-AUC 0.56, PR-AUC 0.086); only 141 fraud labels remain after claim-ID deduplication. Score is not calibrated. Rule-based explanations are not model attributions. Repeat serial/partner/customer networks are not modelled explicitly; partner IDs and free text can drift; subgroup performance is not established. The API has no authentication, monitoring, access controls or production audit trail. Do not use for automatic rejection.

**What did you deliberately leave out, and why that rather than something else?**  
No auto-reject threshold or automated payout hold, because false positives create goodwill and service costs and validation is weak. No paid LLM calls, external API, dashboard stack or elaborate deployment because local reproducibility and safe failure matter more. No claims that the model proves fraud or that new partners are the cause.

**Anything you built or found that nobody asked for?**  
A policy-aware feature for the 1 May 2026 under-₹2,000 auto-approval change; explicit handling of undecided outcomes and repeated claim IDs; cost framing based on ₹380 goodwill, ₹260 service contacts, and 40 reviews/month; and a warning not to publish the restricted operational data.

**What did you use AI for? Which tools and models, where they helped, where they wasted your time, what you threw away. Link your three-minute screen recording here.**  
ChatGPT (OpenAI) assisted with code scaffolding, debugging, feature design, documentation and the evaluation narrative. No paid model/API calls were used inside the product. I discarded the idea of optimizing for accuracy alone and avoided claims of >97% model performance. Verify the exact model name from your ChatGPT interface before submitting. Screen recording: **[PASTE YOUR PUBLIC/APPROVED RECORDING LINK HERE]**.

**Your Public Google Drive Link**  
**[PASTE APPROVED LINK HERE — do not share restricted claim data publicly]**

**Someone picks this up on Monday and you are unreachable. The three things they need to know.**  
1. The model is a prototype only; do not use it to auto-reject or delay claims. Validation ROC-AUC is 0.56 and PR-AUC is 0.086.  
2. Run `python src/train_model.py`, then `uvicorn app:app --host 127.0.0.1 --port 8000`; the UI is at localhost:8000 and the API is `/predict`.  
3. Raw data and model artifacts are restricted by policy; don't publish them publicly. Fix label quality, investigate top-ranked cases, and optimize for rupees per review before any pilot.

**Honest hours spent.**  
**[ENTER YOUR ACTUAL HOURS — do not guess or claim hours you did not spend.]**

**Github Repo Link (Public)**  
**[PASTE YOUR REPOSITORY URL HERE AFTER REVIEWING DATA-HANDLING RESTRICTIONS]**

**What does one prediction cost, and what would a month cost at Kestrel's volume (about 750 warranty claims a month)? Show the arithmetic. If you used no paid calls, say so.**  
No paid calls. Marginal paid inference cost = ₹0 per prediction. At 750 claims/month: 750 × ₹0 = ₹0/month for API usage, excluding CPU hosting, electricity, engineering, monitoring and support. Local test runs need no external API key.
